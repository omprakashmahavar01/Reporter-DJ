APP & GAME STUDIO — हिंदी Android प्रोजेक्ट

इस ZIP में Android WebView app project और responsive Hindi dashboard है।
फोन नंबर: +91 9079981416

APK बनाने का तरीका:
1. इस ZIP को extract करके GitHub repository में सभी फाइलें upload करें।
2. GitHub में Actions खोलें।
3. “Build Phone APK” workflow चुनकर Run workflow दबाएँ।
4. सफल build के बाद Artifacts में App-Game-Studio-debug-apk डाउनलोड करें।
5. Artifact ZIP extract करके app-debug.apk लें।

Build setup: JDK 17, Android SDK, Gradle 8.7, Android Gradle Plugin 8.6.1.
यह ZIP source project है; इसमें पहले से compiled APK शामिल नहीं है।

सुरक्षा:
- Keystore, signing passwords और Google service-account JSON को source ZIP या public repository में न रखें।
- Cloud Run को public तभी करें जब public access आपका स्पष्ट उद्देश्य हो; अन्यथा IAM authentication रखें।
- पुरानी/साझा हुई signing credentials को सुरक्षित तरीके से rotate करने पर विचार करें।
